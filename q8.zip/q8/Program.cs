﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program to display the characters and frequency of characters from a given string USING LINQ");


            string inputs;

            Console.WriteLine("Please type your string: ");
            inputs = Console.ReadLine();

            Console.Write("\n");


            var inputQuery =
                from input in inputs
                group input by input into alphabet
                select alphabet;


            Console.WriteLine("The frequency of the characters are: \n");
            foreach (var item in inputQuery)
            {
                Console.WriteLine("Character {0}:  {1} times", item.Key, item.Count());
            }

            Console.ReadKey();


        //The key is the thing that is common in your group.

        //For example if you have a sequence of words and want to group all words on their first letter,
        //then you have a group with words that start with the letter 'a', and a group with words that start with the letter 'b' etc.

        //Or if you group your sequence of words into groups of words that have the same number of characters,
        //than you have a group of words with just one character and a group of words with two characters, one with three characters etc.

        //The Key is the thing you used to group on.So the key is the first letter or the word,
        //or he number of letters in the word when you grouped on number of characters.

        //You can use the key to identify the group.So if you want the group with words that start with the letter 'h',
        //you say you want the element of your group sequence that has a key equal to 'h'.If you grouped on number of characters you can ask for the group with key 4 to get all four letter words.


        //Group keys are unique.You may be certain there is only one such an element,
        //so you can ask for the first (or default if there is no such group)




        }
    }
}
