﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace qn1
{
    class Program
    {
        static void Main(string[] args)
        {

            //method 1
           Console.WriteLine( "Method 1: Write a program in C# Sharp to find the sum of all elements of the array.\n");  
            int[] numbers = { 2, 5, 8 };
            int sum = 0;

            //for loop to find the sum of the elements in the array
            for (int i = 0; i < numbers.Length; i++)
            {
               
                sum +=  numbers[i];

            }

            Console.WriteLine("Sum of all elements stored in the array is: " + sum);
            Console.WriteLine("\n");



            //mmethod 2
            Console.WriteLine("Method 2: Write a program in C# Sharp to find the sum of all elements of the array.\n");

            int[] sumNumbers = new int[50];
            int numOfElements = 0;
            int sumofElements= 0;

            //asking users how many elements they want to be stored in the arrya
            Console.WriteLine("Input the number of elements to be stored in the array: \n");
            numOfElements = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Input {0} elements in the array", numOfElements);

            for (int i =0; i<numOfElements; i++)
            {
                Console.WriteLine("element - {0} : ", i);
                sumNumbers[i] = Convert.ToInt32(Console.ReadLine()); //storing whateva value user typed into this array
            }

            for (int i=0; i<numOfElements; i++)
            {
                sumofElements += sumNumbers[i];  //adding all the array element 
            }
            Console.WriteLine("Sum of all elements stored in the array is: " + sumofElements);







            Console.ReadKey();
        }

    }
}
