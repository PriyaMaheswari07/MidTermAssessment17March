﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q3
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("A Program for a 2D array of size 3x3 and printing the matrix \n");


            //2d array have 2 dimensions
            //hence have like 2 values
            int[,] array2d = new int[3, 3];



            //Asking user to type thei values 
            Console.WriteLine("Input elements in the matrix");
            //to store the values in that aaray
            for (int i=0; i<3; i++) //we specificy 3 here as we  know that the 2d array have size of 3
            {
                for (int j =0; j<3; j++) //we specificy 3 here as we  know that the 2d array have size of 3
                {
                    Console.WriteLine("element - [{0}], [{1}]: ", i, j);

                    array2d[i, j] =Convert.ToInt32( Console.ReadLine());
                }
            }

            Console.WriteLine("The matrix is: ");
            Console.WriteLine(" ");

            for (int i = 0; i < 3; i++) //number of row, hence automaitcally display 3 rows a
            {
                {
                Console.Write("\n"); 
                for (int j = 0; j < 3; j++) //number of column, hence automaitcally display 3 rows a
                {
                    Console.Write(array2d[i, j] + "\t" );
                   //'\t' meanns horizontal way (tab)
                   //also '\t' separate the element , displaying it in matrix

                    //Console.Write means it will display the output in the same line

                }
            
                
            }


            Console.ReadKey();
        }   
     }
    }

