﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q10
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("LINQ: Progran to convert a sting array to string\n");

           
            int numOfElement;
            Console.WriteLine("Please input the number of strings to store in the array \n");

            numOfElement = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Input {0} strings for the array: /n", numOfElement);

            string[] stringArray = new string[numOfElement];
            for (int i = 0; i < numOfElement; i++)
            {
                Console.WriteLine(" Element {0}: ", i);
                stringArray[i] = Console.ReadLine();
            }



           // now to convert string array to string
            string stringVariable = string.Join(", ", stringArray
                           .Select(s => s.ToString())
                           .ToArray());

            //string stringVariable = string.Concat(" ",stringArray);

            Console.WriteLine("Here is the string below created with elements of the above array : {0} ", stringVariable);


            Console.ReadKey();
        }
    }
}
