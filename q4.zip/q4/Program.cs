﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q4
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("A Program in C# to check if input typed matched the correct username and password \n");
            //the correct username: abcd
            //the correct password : 1234

            string username = "abcd";
            string password = "1234";

            string inputUsername;
            string inputPassword;

            int attempts = 0;

            //we gonna use do while loop
            //do
            //{

            //} while ();

            //Reason: We want the user to try to write the username and password once at least
            //hence if code wrong, then let them attemp again (using do loop)




            do //execute the code first always before checkking condition
            {
                Console.Write("Input a username: \n");
                inputUsername = Console.ReadLine();

                Console.Write("Input a password: \n");
                inputPassword = Console.ReadLine();


                if (inputUsername != username || inputPassword !=password) //if username or password is wrong
                {
                    
                    
                    attempts += 1;

                    if (attempts != 3)
                    {
                        Console.WriteLine("You have typed the wrong password or username. Please try again \n");
                    }
                   
                }

                else //if password is correct

                {
                    Console.WriteLine("\n Username and Password entered successfully");

                    break;

                    
                }
            } while (attempts != 3); //the first and second attempt is wrong
            //while check condition then execute code

           //so the while loop, is to ensure the the code still stays in the loop if attempt =1 or 2
           

            if (attempts == 3)
            {
                Console.WriteLine("\n You have entered the wrong username or passwrod in these 3 attempts. You are not allowed to have more attempt!!!");

            }






            Console.ReadKey();

        }

    }
    }


