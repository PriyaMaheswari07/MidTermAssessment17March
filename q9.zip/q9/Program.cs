﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q9
{
    class Program
    {
        static void Main(string[] args)
        {



            Console.Write("Find the string which starts and ends with a specific character using LINQ \n ");


            //test dat
            Console.Write("The cities are : 'ROME','LONDON','NAIROBI','CALIFORNIA','ZURICH','NEW DELHI','AMSTERDAM','ABU DHABI','PARIS' \n");


            string[] cities = { "ROME", "LONDON", "NAIROBI", "CALIFORNIA", "ZURICH", "NEW DEHLI", "AMSTERDAM", "ABU DHABI", "PARIS" };


            string startingChar;
            string endingChar;



            Console.WriteLine("Input starting character for the string: \n");
            startingChar = Console.ReadLine(); //taking in the input typed by user


            Console.WriteLine("Input ending character for the string: \n");
            endingChar = Console.ReadLine(); //taking in the input typed by user


            var result =
               from city in cities
               where city.StartsWith(startingChar)
               where city.EndsWith(endingChar)
               select city;

            foreach (var item in result)
            {
                Console.WriteLine("The city starting with {0} and ending with {1} is : {2}", startingChar, endingChar, item);
            }



            Console.ReadKey();

        }


    }
    
}
