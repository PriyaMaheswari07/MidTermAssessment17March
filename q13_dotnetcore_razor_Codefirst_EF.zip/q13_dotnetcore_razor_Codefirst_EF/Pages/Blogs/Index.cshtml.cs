﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using q13_dotnetcore_razor_Codefirst_EF.Data;
using q13_dotnetcore_razor_Codefirst_EF.Models;

namespace q13_dotnetcore_razor_Codefirst_EF.Pages.Blogs
{
    public class IndexModel : PageModel
    {
        private readonly q13_dotnetcore_razor_Codefirst_EF.Data.BlogContext _context;

        public IndexModel(q13_dotnetcore_razor_Codefirst_EF.Data.BlogContext context)
        {
            _context = context;
        }

        public IList<Blog> Blog { get;set; }

        public async Task OnGetAsync()
        {
            Blog = await _context.Blog.ToListAsync();
        }
    }
}
