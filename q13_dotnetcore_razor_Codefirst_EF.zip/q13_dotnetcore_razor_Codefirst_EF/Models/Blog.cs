﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations; // we added this for date function to work
using System.Linq;
using System.Threading.Tasks;

namespace q13_dotnetcore_razor_Codefirst_EF.Models
{
    public class Blog
    {

        [Key]

        public int BlogID { get; set; }

        //to define the length of the blog content
        [StringLength(120, MinimumLength =100)]
        public string BlogContent { get; set; }

        [DataType(DataType.Date)] //date function attribute
        public DateTime PostingDate { get; set; }
       
        public string AuthorName { get; set; }

        public int NumOfLikes { get; set; }



    }
}
