﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace qn6
{
    class Program
    {
        static void Main(string[] args)
        {

            //this main coding aread(method) is for calling the conversion menthod, and the display of the poutput (the objects)

            int number;

            //first example
            number = 2365;
            Console.WriteLine("Original integer value:" + number);
            Console.WriteLine("Roman numerals of the said integer value: {0}", Conversion(number)); //calling method
            
            //second example
            number = 254;
            Console.WriteLine("Original integer value:" + number);
            Console.WriteLine("Roman numerals of the said integer value: {0}", Conversion(number));//calling method


            //3rd example
            number = 45;
            Console.WriteLine("Original integer value:" + number);
            Console.WriteLine("Roman numerals of the said integer value: {0}", Conversion(number));//calling method


            number = 8;
            Console.WriteLine("Original integer value:" + number);
            Console.WriteLine("Roman numerals of the said integer value: {0}", Conversion(number));//calling method


            Console.ReadKey();

        }


        public static string Conversion(int number) //public static is a static method that is accessible to external callers.
        {
            if (number >= 1000) return "M" + Conversion(number -1000);
            //if (number >= 900) return "CM" + Conversion(number - 900);
            if (number >= 500) return "D" + Conversion(number - 500);
            //if (number >= 400) return "CD" + Conversion(number - 400);
            if (number >= 100) return "C" + Conversion(number - 100);
            if (number >= 90) return "XC" + Conversion(number - 90);
            if (number >= 50) return "L" + Conversion(number - 50);
           // if (number >= 40) return "XL" + Conversion(number - 40);
            if (number >= 10) return "X" + Conversion(number - 10);
          //  if (number >= 9) return "IX" + Conversion(number - 9);
            if (number >= 5) return "V" + Conversion(number - 5);
           // if (number >= 4) return "IV" + Conversion(number - 4);
            if (number >= 1) return "I" + Conversion(number - 1);
            throw new ArgumentOutOfRangeException("value invalide");


        }

        
    }
    }

