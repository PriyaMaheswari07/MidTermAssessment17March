﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q2
{
    class Program
    {
        static void Main(string[] args)
        {


            //creating an empty erray that accept 50 elements
            int[] inputArray = new int[50]; //the arrayList.Length  =50 always. hence cannot use this for the for loop
            int[] uniqueArray = new int[50]; //the arrayList.Length  =50 always. hence cannot use this for the for loop

            int numElements;



            Console.WriteLine(" Program to print all unique elements in an array.\n");

            //asking users how many eleements they want in the array
            Console.WriteLine("Input the number of elements to be stored in the array:");

            numElements = Convert.ToInt32(Console.ReadLine());
            //conver that output to int (since hour array is integer). and the user's output is in string

            //display the number of elements the the users wants to be stored in the array
            Console.WriteLine("Input " + numElements + " elements in the array: \n");

            for (int i = 0; i < numElements; i++)
            {
                Console.WriteLine("element - {0}:", i);

                //store number entered into the array 'uniqueArray'. This is the array that will keep the work
                inputArray[i] = Convert.ToInt32(Console.ReadLine());
                //all entered value will be stored as an element in this array

            }




            Console.Write("\nThe unique elements found in the array are : \n");

            int numberOfArray = 0; 
            //two logic:
            //the index of the unique value in the unique array
            //also indidicate the number of elements in the uniq array

            for (int i = 0; i < numElements; i++) //to loop all the element in the inputArray
            {
                int currentNumber = inputArray[i]; //asume the first element to be 'currentNumber'
                bool isDuplicate = false;  //the value is unique

                //second loop to compare curretn number to other elements
                for (int position = 0; position < numElements; position++)
                {
                    if (i != position) //we write this so that we don't compare curretn number to itself
                    {
                        if (inputArray[i] == inputArray[position]) //if the other number and curretn number is of same value
                        {
                            isDuplicate = true; // boolean value become true
                                               //hence duplicate value
                        }
                    }
                }

               
                if (isDuplicate == false)  //unique value
                {
                    //include the unique values into the unique array
                    //we include the unique value using the 'numberofArray' 
                    //since this 'numberofArray' indicate the index of the unique value in the unique array.
                    //we use this to include the uniqe value
                    uniqueArray[numberOfArray] = currentNumber;
                    numberOfArray++; //increase the value of the 'numberOFArray' by 1, to increase the index and  number of elements in uniqarray
                }
            }

            //loop through the new unique array containing unique values
            for (int x = 0; x < numberOfArray; x++)
            {
                Console.Write(uniqueArray[x] + " ");
            }

            Console.ReadKey();
        }
    }
}
